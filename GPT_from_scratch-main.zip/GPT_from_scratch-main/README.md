# GPT from scratch

Very simple implementation of GPT architecture. 

Based on A. Karpathy's code. Needs just PyTorch and Jupyter.
